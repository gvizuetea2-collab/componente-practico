from django.db import models

# Este proyecto no utiliza modelos en la base de datos.
