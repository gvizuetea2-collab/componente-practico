import re
from django.shortcuts import render
from .forms import NumberListForm


def parse_number_list(value):
    tokens = re.split(r'[;,\s]+', value.strip())
    numbers = []
    for token in tokens:
        if token:
            try:
                numbers.append(int(token))
            except ValueError:
                raise ValueError(f'Valor inválido: "{token}"')
    if not numbers:
        raise ValueError('Debe ingresar al menos un número.')
    return numbers


def index(request):
    form = NumberListForm(request.POST or None)
    context = {'form': form}

    if request.method == 'POST' and form.is_valid():
        raw_numbers = form.cleaned_data['numbers']
        try:
            numbers = parse_number_list(raw_numbers)
        except ValueError as exc:
            form.add_error('numbers', str(exc))
            return render(request, 'numeros/index.html', context)

        total = sum(numbers)
        promedio = total / len(numbers)
        mayor = max(numbers)
        menor = min(numbers)
        pares = list(filter(lambda n: n % 2 == 0, numbers))
        impares = list(filter(lambda n: n % 2 != 0, numbers))
        cuadrados = list(map(lambda n: n * n, numbers))
        multiplos_de_tres = list(filter(lambda n: n % 3 == 0, numbers))
        triples_de_multiplos_de_tres = list(map(lambda n: n * 3, multiplos_de_tres))

        context.update({
            'results': {
                'numbers': numbers,
                'total': total,
                'promedio': promedio,
                'mayor': mayor,
                'menor': menor,
                'pares': pares,
                'impares': impares,
                'cuadrados': cuadrados,
                'multiplos_de_tres': multiplos_de_tres,
                'triples_de_multiplos_de_tres': triples_de_multiplos_de_tres,
            }
        })

    return render(request, 'numeros/index.html', context)
