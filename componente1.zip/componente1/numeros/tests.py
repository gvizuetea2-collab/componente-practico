from django.test import TestCase


class AnalizadorNumerosTests(TestCase):
    def test_index_page_renders(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Analizador de Números')
