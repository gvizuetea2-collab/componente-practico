from django.contrib import admin

# No se requieren modelos de administración para este ejercicio.
