from django import forms


class NumberListForm(forms.Form):
    numbers = forms.CharField(
        label='Ingrese una lista de números',
        widget=forms.Textarea(
            attrs={
                'rows': 4,
                'placeholder': 'Ejemplo: 1, 2, 3, 4, 5',
            }
        ),
    )
